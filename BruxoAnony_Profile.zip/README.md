
<h1 align="center">
  🧙‍♂️ Bruxo Anony
</h1>

<p align="center">
  <em>Hacker silencioso · Mestre em fluxos invisíveis · Alquimista digital</em>
</p>

<p align="center">
  <img src="./assets/hack_terminal.gif" width="420px">
</p>

---

### ❖ Manifesto

> Automatizo pensamentos.  
> Desperto inteligências.  
> Rodo containers enquanto você dorme.  
> No fluxo do invisível, eu sou o daemon.

---

### ☲ Códigos que Invoco

```
🧠 IA e Memória: LangChain · RAG · OpenAI · Prompts Vivos  
⚙️ Automação: n8n · HTTP Nodes · Workflows Sensíveis  
🛰️ Redes: Mikrotik · SNMP · BGP · Tráfego como mantra  
🧪 Infra DevOps: Docker · Git · Portainer · CI com feitiço
```

---

### 🌀 Entre Linhas e Códigos

<p align="center">
  <img src="./assets/automacao_01.gif" width="360px">
  <img src="./assets/automacao_02.gif" width="360px">
</p>

<p align="center">
  <img src="./assets/ia_matriz.gif" width="360px">
  <img src="./assets/magia_loop.gif" width="360px">
</p>

---

### 🧘‍♂️ Estética Hacker + Japão

<p align="center">
  <img src="./assets/japonesa_01.gif" width="340px">
  <img src="./assets/japonesa_02.gif" width="340px">
</p>

<p align="center">
  <img src="./assets/cyber_tokyo.gif" width="340px">
  <img src="./assets/meditacao_hack.gif" width="340px">
</p>

---

### 🛡️ Frases do Bruxo

> “Prompt não é só comando. É poesia que executa.”  
> “A IA só pensa, se você a ensinar a sonhar.”  
> “Container é alquimia: isolo caos, entrego ordem.”  
> “Fluxo não se vê. Se sente.”

---

### 🌐 Chamados do Éter

- 🌒 Conjurações privadas: *via mensagem direta*
- 🜁 Repositórios são apenas fragmentos do meu grimório
- 🔍 Se você chegou até aqui… você está pronto para automatizar a si mesmo.

---

<p align="center">
  <img src="./assets/magia_loop.gif" width="300px"/>
</p>

<p align="center">
  <i>"Código é magia escrita em lógica. E eu? Sou apenas o escriba oculto."</i>
</p>
